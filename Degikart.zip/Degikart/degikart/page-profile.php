<?php
/* Template Name: Profile Page */
get_header();
?>
<div id="site-width">
<div class="profile-container">
    <?php echo do_shortcode('[custom_profile]'); ?>
</div>
</div>
<?php
get_footer();
?>
